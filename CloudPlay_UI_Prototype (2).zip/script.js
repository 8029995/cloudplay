const games=[
  {name:"Blox Fruits",players:"214K playing",emoji:"⚔️",cls:"t1"},
  {name:"Brookhaven RP",players:"92K playing",emoji:"🏙️",cls:"t2"},
  {name:"Murder Mystery 2",players:"67K playing",emoji:"🔪",cls:"t3"},
  {name:"Tower of Hell",players:"31K playing",emoji:"🗼",cls:"t4"}
];
const gamesEl=document.getElementById("games");
function render(list){
  gamesEl.innerHTML=list.length?list.map(g=>`<article class="game-card" data-game="${g.name}"><div class="thumb ${g.cls}"><span>${g.emoji}</span></div><div class="game-info"><b>${g.name}</b><small>${g.players}</small></div></article>`).join(""):`<div style="grid-column:1/-1;color:#7e8a9d;padding:30px;text-align:center">No games found.</div>`;
  document.querySelectorAll(".game-card").forEach(c=>c.onclick=()=>launch(c.dataset.game));
}
render(games);

const modal=document.getElementById("modal"), title=document.getElementById("modalTitle"), text=document.getElementById("modalText");
function launch(name="Roblox"){
  title.textContent="Starting "+name;
  text.textContent="The cloud-streaming connection is not connected in this prototype yet. This screen is ready for the real game session to plug in.";
  modal.classList.add("show");
}
document.getElementById("heroPlay").onclick=()=>launch("Roblox");
document.getElementById("close").onclick=()=>modal.classList.remove("show");
document.getElementById("close2").onclick=()=>modal.classList.remove("show");
document.getElementById("learnBtn").onclick=()=>{title.textContent="How CloudPlay works";text.textContent="A future version can connect this interface to a cloud gaming server, stream the game to your browser, and select a nearby server to reduce latency.";modal.classList.add("show")};
document.getElementById("seeAll").onclick=()=>{document.getElementById("search").focus();document.getElementById("search").select()};
document.getElementById("search").addEventListener("input",e=>{
  const q=e.target.value.toLowerCase().trim();
  render(games.filter(g=>g.name.toLowerCase().includes(q)));
});
setInterval(()=>{document.getElementById("ping").textContent=(22+Math.floor(Math.random()*9))+" ms"},3000);
